package br.edu.unifaj.cc.poo.pingoosbmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PingooSbMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
