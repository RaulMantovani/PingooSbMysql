package br.edu.unifaj.cc.poo.pingoosbmysql.controller;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaResponse;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.NotaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.service.AulaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/aulas")
@CrossOrigin
public class AulaController {

    @Autowired
    private AulaService aulaService;

    @GetMapping
    public List<AulaResponse> listarAulas(@RequestHeader("usuario") String nomeUsuario) {
        return aulaService.listar(nomeUsuario);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AulaResponse> buscarPorId(
            @PathVariable long id,
            @RequestHeader("usuario") String nomeUsuario) {

        try {
            AulaResponse aula = aulaService.buscarPorId(id, nomeUsuario);
            return ResponseEntity.ok(aula);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/notas")
    public ResponseEntity<AulaResponse> adicionarNota(
            @PathVariable long id,
            @RequestBody NotaRequest notaRequest,
            @RequestHeader("usuario") String nomeUsuario) {

        try {
            AulaResponse atualizada = aulaService.adicionarNota(id, notaRequest, nomeUsuario);
            return ResponseEntity.ok(atualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public AulaResponse adicionarAula(
            @RequestBody AulaRequest request,
            @RequestHeader("usuario") String nomeUsuario) {
        return aulaService.adicionar(request, nomeUsuario);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AulaResponse> atualizarAula(
            @PathVariable long id,
            @RequestBody AulaRequest request,
            @RequestHeader("usuario") String nomeUsuario) {
        try {
            AulaResponse atualizada = aulaService.atualizarAula(id, request, nomeUsuario);
            return ResponseEntity.ok(atualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarAula(
            @PathVariable Long id,
            @RequestHeader("usuario") String nomeUsuario) {
        try {
            aulaService.deletar(id, nomeUsuario);
            return ResponseEntity.ok("Aula deletada com sucesso.");
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
