package br.edu.unifaj.cc.poo.pingoosbmysql.controller;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.*;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import br.edu.unifaj.cc.poo.pingoosbmysql.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/registrar")
    public UsuarioResponse registrar(@RequestBody UsuarioRegistro dto) {
        return usuarioService.registrar(dto);
    }

    @PostMapping("/login")
    public UsuarioResponse login(@RequestBody UsuarioLogin dto) {
        return usuarioService.login(dto);
    }

    @GetMapping("/listar")
    public List<Usuario> listar() {
        return usuarioService.listar();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarUsuario(@PathVariable Long id) {
        try {
            usuarioService.deletar(id);
            return ResponseEntity.ok("Usuário deletado com sucesso.");
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
