package br.edu.unifaj.cc.poo.pingoosbmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PingooSbMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PingooSbMySqlApplication.class, args);
	}

}
