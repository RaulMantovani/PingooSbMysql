package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsuarioRegistro {
    private String usuario;
    private String email;
    private String senha;
}
