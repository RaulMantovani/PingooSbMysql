package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.Data;

@Data
public class UsuarioRegistro {
    private String usuario;
    private String email;
    private String senha;
}
