package br.edu.unifaj.cc.poo.pingoosbmysql.controller;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.EventoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Evento;
import br.edu.unifaj.cc.poo.pingoosbmysql.service.EventoService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/calendario")
@CrossOrigin
public class CalendarioController {

    private final EventoService service;

    public CalendarioController(EventoService service) {
        this.service = service;
    }

    @GetMapping("/listar")
    public List<Evento> listarEventos(@RequestHeader("usuario") String usuario) {
        return service.listar(usuario);
    }

    @GetMapping("/dia/{data}")
    public List<Evento> listarPorDia(@RequestHeader("usuario") String usuario,
                                     @PathVariable String data) {
        LocalDate dataEvento = LocalDate.parse(data);
        return service.listarPorDia(usuario, dataEvento);
    }

    @GetMapping("/semana/{data}")
    public List<Evento> listarPorSemana(@RequestHeader("usuario") String usuario,
                                        @PathVariable String data) {
        LocalDate dataEvento = LocalDate.parse(data);
        return service.listarPorSemana(usuario, dataEvento);
    }

    @PostMapping("/registrar")
    public Evento registrarEvento(@RequestHeader("usuario") String usuario,
                                  @RequestBody EventoRequest req) {
        return service.registrar(usuario, req);
    }
}
