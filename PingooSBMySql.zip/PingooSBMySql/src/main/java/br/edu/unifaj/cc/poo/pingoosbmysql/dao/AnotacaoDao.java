package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Anotacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnotacaoDao extends JpaRepository<Anotacao, Long> {
}
