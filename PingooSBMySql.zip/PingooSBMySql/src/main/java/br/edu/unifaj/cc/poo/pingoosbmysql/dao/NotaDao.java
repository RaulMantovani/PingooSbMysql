package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Nota;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotaDao extends JpaRepository<Nota, Long> {
}

