package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Nota;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotaDao extends JpaRepository<Nota, Long> {
}

