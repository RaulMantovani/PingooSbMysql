package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaResponse;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.NotaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Aula;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Nota;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.AulaDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.NotaDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.UsuarioDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AulaService {

    @Autowired
    private AulaDao aulaRepository;

    @Autowired
    private NotaDao notaRepository;

    @Autowired
    private UsuarioDao usuarioRepository;

    public List<AulaResponse> listar(String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        return aulaRepository.findByUsuario(usuario)
                .stream()
                .map(this::toResponse)
                .toList();
    }


    public AulaResponse buscarPorId(long id, String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        Aula aula = aulaRepository.findByIdAndUsuario(id, usuario)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada ou não pertence a este usuário."));

        return toResponse(aula);
    }


    public AulaResponse adicionar(AulaRequest request, String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        Aula nova = new Aula();
        nova.setMateria(request.getMateria());
        nova.setProfessor(request.getProfessor());
        nova.setDiaSemana(request.getDiaSemana());
        nova.setUsuario(usuario);

        Aula salva = aulaRepository.save(nova);
        return toResponse(salva);
    }


    public AulaResponse atualizarAula(long id, AulaRequest request, String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        Aula aula = aulaRepository.findByIdAndUsuario(id, usuario)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada ou não pertence ao usuário."));

        aula.setMateria(request.getMateria());
        aula.setProfessor(request.getProfessor());
        aula.setDiaSemana(request.getDiaSemana());

        Aula atualizada = aulaRepository.save(aula);
        return toResponse(atualizada);
    }


    public AulaResponse adicionarNota(long id, NotaRequest notaRequest, String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        Aula aula = aulaRepository.findByIdAndUsuario(id, usuario)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada ou não pertence ao usuário."));

        Nota nota = new Nota();
        nota.setValor(notaRequest.getValor());
        nota.setDescricao(notaRequest.getDescricao());

        notaRepository.save(nota);
        aula.getNotas().add(nota);

        Aula atualizada = aulaRepository.save(aula);
        return toResponse(atualizada);
    }

    public void deletar(Long id, String nomeUsuario) {
        Usuario usuario = usuarioRepository.findByUsuario(nomeUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));

        Aula aula = aulaRepository.findByIdAndUsuario(id, usuario)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada ou não pertence ao usuário."));

        aulaRepository.delete(aula);
    }

    private AulaResponse toResponse(Aula aula) {
        return new AulaResponse(
                aula.getId().intValue(),
                aula.getMateria(),
                aula.getProfessor(),
                aula.getDiaSemana(),
                aula.getNotas(),
                aula.getAnotacoes()
        );
    }
}
