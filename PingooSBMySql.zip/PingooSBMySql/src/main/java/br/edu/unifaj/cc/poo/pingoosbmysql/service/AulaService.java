package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AulaResponse;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.NotaRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Aula;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Nota;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.AulaDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.NotaDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AulaService {

    @Autowired
    private AulaDao aulaRepository;

    @Autowired
    private NotaDao notaRepository;

    public List<AulaResponse> listar() {
        return aulaRepository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public AulaResponse buscarPorId(long id) {
        return aulaRepository.findById(id)
                .map(this::toResponse)
                .orElse(null);
    }

    public AulaResponse adicionar(AulaRequest request) {
        Aula nova = new Aula();
        nova.setMateria(request.getMateria());
        nova.setProfessor(request.getProfessor());
        nova.setDiaSemana(request.getDiaSemana());
        Aula salva = aulaRepository.save(nova);
        return toResponse(salva);
    }

    public AulaResponse atualizarAula(long id, AulaRequest request) {
        Optional<Aula> opt = aulaRepository.findById(id);
        if (opt.isEmpty()) {
            throw new RuntimeException("Aula não encontrada com id: " + id);
        }

        Aula aula = opt.get();
        aula.setMateria(request.getMateria());
        aula.setProfessor(request.getProfessor());
        aula.setDiaSemana(request.getDiaSemana());
        Aula atualizada = aulaRepository.save(aula);

        return toResponse(atualizada);
    }

    public AulaResponse adicionarNota(long id, NotaRequest notaRequest) {
        Aula aula = aulaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada com id: " + id));

        Nota nota = new Nota();
        nota.setValor(notaRequest.getValor());
        nota.setDescricao(notaRequest.getDescricao());

        notaRepository.save(nota);
        aula.getNotas().add(nota);

        Aula atualizada = aulaRepository.save(aula);
        return toResponse(atualizada);
    }

    private AulaResponse toResponse(Aula aula) {
        return new AulaResponse(
                aula.getId().intValue(),
                aula.getMateria(),
                aula.getProfessor(),
                aula.getDiaSemana(),
                aula.getNotas(),
                aula.getAnotacoes()
        );
    }

    public void deletar(Long id) {
        if (!aulaRepository.existsById(id)) {
            throw new RuntimeException("Aula não encontrada.");
        }
        aulaRepository.deleteById(id);
    }
}
