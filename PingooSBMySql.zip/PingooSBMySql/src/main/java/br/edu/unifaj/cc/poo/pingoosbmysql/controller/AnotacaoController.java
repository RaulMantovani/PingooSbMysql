package br.edu.unifaj.cc.poo.pingoosbmysql.controller;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AnotacaoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Anotacao;
import br.edu.unifaj.cc.poo.pingoosbmysql.service.AnotacaoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/anotacoes")
@CrossOrigin
public class AnotacaoController {

    private final AnotacaoService service;

    public AnotacaoController(AnotacaoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Anotacao> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Anotacao> buscarPorId(@PathVariable Long id) {
        Anotacao anotacao = service.buscarPorId(id);
        if (anotacao != null) {
            return ResponseEntity.ok(anotacao);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public Anotacao adicionar(@RequestBody AnotacaoRequest request) {
        return service.adicionar(request);
    }

    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Long id) {
        service.excluir(id);
    }

    @PutMapping("/{id}")
    public Anotacao atualizar(@PathVariable Long id, @RequestBody AnotacaoRequest request) {
        return service.atualizar(id, request);
    }
}
