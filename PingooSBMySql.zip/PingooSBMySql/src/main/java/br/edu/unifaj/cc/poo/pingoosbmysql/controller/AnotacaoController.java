package br.edu.unifaj.cc.poo.pingoosbmysql.controller;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AnotacaoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Anotacao;
import br.edu.unifaj.cc.poo.pingoosbmysql.service.AnotacaoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/anotacoes")
@CrossOrigin
public class AnotacaoController {

    private final AnotacaoService service;

    public AnotacaoController(AnotacaoService service) {
        this.service = service;
    }

    // 🔹 Anotações gerais (sem aula)
    @GetMapping
    public List<Anotacao> listarGerais(@RequestHeader("usuario") String usuario) {
        return service.listarGerais(usuario);
    }

    @PostMapping
    public Anotacao criarGeral(@RequestHeader("usuario") String usuario,
                               @RequestBody AnotacaoRequest req) {
        return service.adicionar(usuario, req);
    }

    // 🔹 Anotações específicas de uma aula
    @GetMapping("/aula/{aulaId}")
    public List<Anotacao> listarPorAula(@RequestHeader("usuario") String usuario,
                                        @PathVariable Long aulaId) {
        return service.listarPorAula(usuario, aulaId);
    }

    @PostMapping("/aula/{aulaId}")
    public Anotacao criarParaAula(@RequestHeader("usuario") String usuario,
                                  @PathVariable Long aulaId,
                                  @RequestBody AnotacaoRequest req) {
        req.setAulaId(aulaId);
        return service.adicionar(usuario, req);
    }
}
