package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioDao extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByUsuario(String usuario);
    boolean existsByEmail(String email);
    boolean existsByUsuario(String usuario);
}
