package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

public class UsuarioDao {
}
