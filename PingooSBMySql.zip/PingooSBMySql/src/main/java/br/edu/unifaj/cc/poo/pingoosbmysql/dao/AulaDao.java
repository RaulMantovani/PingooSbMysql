package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Aula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AulaDao extends JpaRepository<Aula, Long> {
}

