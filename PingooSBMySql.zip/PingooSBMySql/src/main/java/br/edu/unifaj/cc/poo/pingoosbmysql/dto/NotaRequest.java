package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.Data;

@Data
public class NotaRequest {
    private float valor;
    private String descricao;
}
