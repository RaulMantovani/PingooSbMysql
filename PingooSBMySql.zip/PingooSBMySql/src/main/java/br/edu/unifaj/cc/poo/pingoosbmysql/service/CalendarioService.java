package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.CalendarioRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.CalendarioResponse;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Calendario;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.CalendarioDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalendarioService {

    private final CalendarioDao repository;

    public CalendarioService(CalendarioDao repository) {
        this.repository = repository;
    }

    public CalendarioResponse registrar(CalendarioRequest request) {
        Calendario novo = new Calendario();
        novo.setNomeEvento(request.getNomeEvento());
        novo.setDataEvento(request.getDataEvento());
        repository.save(novo);

        return new CalendarioResponse("Evento registrado com sucesso.");
    }

    public List<Calendario> listar() {
        return repository.findAll();
    }

    public Calendario buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Calendario atualizar(Long id, CalendarioRequest request) {
        Calendario existente = repository.findById(id).orElse(null);
        if (existente != null) {
            existente.setNomeEvento(request.getNomeEvento());
            existente.setDataEvento(request.getDataEvento());
            return repository.save(existente);
        }
        return null;
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }
}

