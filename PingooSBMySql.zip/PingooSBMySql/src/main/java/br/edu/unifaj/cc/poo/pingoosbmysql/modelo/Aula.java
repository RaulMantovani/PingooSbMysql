package br.edu.unifaj.cc.poo.pingoosbmysql.modelo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "aulas")
public class Aula {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String materia;
    private String professor;
    private String diaSemana;

    @ElementCollection
    private List<String> anotacoes = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Nota> notas = new ArrayList<>();

 /*   public Aula(long andIncrement, String materia, String professor, String diaSemana) {
        this.id = andIncrement;
        this.materia = materia;
        this.professor = professor;
        this.diaSemana = diaSemana;
        this.anotacoes = new java.util.ArrayList<>();
        this.notas = new java.util.ArrayList<>();
    }

  */
}
