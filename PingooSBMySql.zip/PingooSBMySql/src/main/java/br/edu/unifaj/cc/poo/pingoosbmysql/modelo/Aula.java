package br.edu.unifaj.cc.poo.pingoosbmysql.modelo;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "aulas")
public class Aula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String materia;
    private String professor;
    private String diaSemana;

    @ElementCollection
    private List<String> anotacoes;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Nota> notas;

    @ManyToOne
    @JoinColumn(name = "usuario_id") // ligação com o usuário dono da aula
    private Usuario usuario;
}
