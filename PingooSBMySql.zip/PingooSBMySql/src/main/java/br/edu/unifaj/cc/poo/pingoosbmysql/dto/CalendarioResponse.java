package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CalendarioResponse {
    private String mensagem;
}

