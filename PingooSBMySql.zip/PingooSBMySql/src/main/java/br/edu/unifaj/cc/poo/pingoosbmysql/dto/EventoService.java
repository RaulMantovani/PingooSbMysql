package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dao.EventoDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.UsuarioDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.EventoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Evento;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@Service
public class EventoService {

    private final EventoDao eventoDao;
    private final UsuarioDao usuarioDao;

    public EventoService(EventoDao eventoDao, UsuarioDao usuarioDao) {
        this.eventoDao = eventoDao;
        this.usuarioDao = usuarioDao;
    }

    public List<Evento> listar(String usuarioNome) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return eventoDao.findByUsuario(usuario);
    }

    public List<Evento> listarPorDia(String usuarioNome, LocalDate data) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return eventoDao.findByUsuarioAndDataEvento(usuario, data);
    }

    public List<Evento> listarPorSemana(String usuarioNome, LocalDate data) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        LocalDate inicio = data.with(TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
        LocalDate fim = inicio.plusDays(6);
        return eventoDao.findByUsuarioAndDataEventoBetween(usuario, inicio, fim);
    }

    public Evento registrar(String usuarioNome, EventoRequest req) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        Evento evento = new Evento();
        evento.setNomeEvento(req.getNomeEvento());
        evento.setDataEvento(req.getDataEvento());
        evento.setUsuario(usuario);

        return eventoDao.save(evento);
    }
}

