package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Calendario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalendarioDao extends JpaRepository<Calendario, Long> {
}

