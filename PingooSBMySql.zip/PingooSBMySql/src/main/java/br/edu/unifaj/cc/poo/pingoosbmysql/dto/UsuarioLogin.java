package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.Data;

@Data
public class UsuarioLogin {
    private String usuario;
    private String senha;
}
