package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.UsuarioLogin;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.UsuarioRegistro;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.UsuarioResponse;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.UsuarioDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioDao usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UsuarioResponse registrar(UsuarioRegistro dto) {
        if (usuarioRepository.existsByEmail(dto.getEmail())) {
            return new UsuarioResponse("Email já cadastrado.");
        }
        if (usuarioRepository.existsByUsuario(dto.getUsuario())) {
            return new UsuarioResponse("Usuário já existe.");
        }

        String senhaCriptografada = passwordEncoder.encode(dto.getSenha());

        Usuario novo = new Usuario(dto.getUsuario(), dto.getEmail(), dto.getSenha());
        usuarioRepository.save(novo);

        return new UsuarioResponse("Usuário registrado com sucesso.");
    }

    public UsuarioResponse login(UsuarioLogin dto) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByUsuario(dto.getUsuario());

        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            if (passwordEncoder.matches(dto.getSenha(), usuario.getSenha())) {
                return new UsuarioResponse("Login bem-sucedido.");
            }
        }

        return new UsuarioResponse("Usuário ou senha inválidos.");
    }

    public List<Usuario> listar() {
        return usuarioRepository.findAll();
    }

    public void deletar(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new RuntimeException("Usuário não encontrado.");
        }
        usuarioRepository.deleteById(id);
    }
}
