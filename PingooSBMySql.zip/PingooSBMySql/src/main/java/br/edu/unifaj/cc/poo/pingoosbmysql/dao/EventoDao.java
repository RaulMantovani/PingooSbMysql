package br.edu.unifaj.cc.poo.pingoosbmysql.dao;

import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Evento;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EventoDao extends JpaRepository<Evento, Long> {

    List<Evento> findByUsuario(Usuario usuario);

    List<Evento> findByUsuarioAndDataEventoBetween(Usuario usuario, LocalDate inicio, LocalDate fim);

    List<Evento> findByUsuarioAndDataEvento(Usuario usuario, LocalDate dataEvento);
}

