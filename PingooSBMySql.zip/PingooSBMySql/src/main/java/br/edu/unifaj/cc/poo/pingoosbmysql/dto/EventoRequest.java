package br.edu.unifaj.cc.poo.pingoosbmysql.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class EventoRequest {
    private String nomeEvento;
    private LocalDate dataEvento;

}
