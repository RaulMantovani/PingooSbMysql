package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AnotacaoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Anotacao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.AnotacaoDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnotacaoService {

    private final AnotacaoDao repository;

    public AnotacaoService(AnotacaoDao repository) {
        this.repository = repository;
    }

    public List<Anotacao> listar() {
        return repository.findAll();
    }

    public Anotacao buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Anotacao adicionar(AnotacaoRequest request) {
        Anotacao nova = new Anotacao();
        nova.setTitulo(request.getTitulo());
        nova.setConteudo(request.getConteudo());
        return repository.save(nova);
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    public Anotacao atualizar(Long id, AnotacaoRequest request) {
        Anotacao anotacao = repository.findById(id).orElse(null);
        if (anotacao != null) {
            anotacao.setTitulo(request.getTitulo());
            anotacao.setConteudo(request.getConteudo());
            return repository.save(anotacao);
        }
        return null;
    }
}
