package br.edu.unifaj.cc.poo.pingoosbmysql.service;

import br.edu.unifaj.cc.poo.pingoosbmysql.dao.AnotacaoDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.AulaDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dao.UsuarioDao;
import br.edu.unifaj.cc.poo.pingoosbmysql.dto.AnotacaoRequest;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Anotacao;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Aula;
import br.edu.unifaj.cc.poo.pingoosbmysql.modelo.Usuario;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnotacaoService {

    private final AnotacaoDao anotacaoDao;
    private final UsuarioDao usuarioDao;
    private final AulaDao aulaDao;

    public AnotacaoService(AnotacaoDao anotacaoDao, UsuarioDao usuarioDao, AulaDao aulaDao) {
        this.anotacaoDao = anotacaoDao;
        this.usuarioDao = usuarioDao;
        this.aulaDao = aulaDao;
    }

    public List<Anotacao> listarGerais(String usuarioNome) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return anotacaoDao.findByUsuarioAndAula(usuario, null);
    }

    public List<Anotacao> listarPorAula(String usuarioNome, Long aulaId) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        Aula aula = aulaDao.findById(aulaId)
                .orElseThrow(() -> new RuntimeException("Aula não encontrada"));
        return anotacaoDao.findByUsuarioAndAula(usuario, aula);
    }

    public Anotacao adicionar(String usuarioNome, AnotacaoRequest req) {
        Usuario usuario = usuarioDao.findByUsuario(usuarioNome)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        Anotacao anotacao = new Anotacao();
        anotacao.setTitulo(req.getTitulo());
        anotacao.setConteudo(req.getConteudo());
        anotacao.setUsuario(usuario);

        if (req.getAulaId() != null) {
            Aula aula = aulaDao.findById(req.getAulaId())
                    .orElseThrow(() -> new RuntimeException("Aula não encontrada"));
            anotacao.setAula(aula);
        }

        return anotacaoDao.save(anotacao);
    }
}
