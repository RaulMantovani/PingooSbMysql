package br.edu.unifaj.cc.poo.pingoosbmysql.modelo;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "eventos_calendario")
public class Calendario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomeEvento;
    private LocalDate dataEvento;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;
}
